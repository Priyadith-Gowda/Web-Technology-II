<?php include('../functions.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration system PHP and MySQL - Create user</title>
	<link rel="stylesheet" type="text/css" href="../style.css">
	<style>
		.header {
			background: #003366;
		}
		button[name=register_btn] {
			background: #003366;
		}
	</style>
</head>
<body>
	<div class="header">
		<h2>Admin - create user</h2>
	</div>
	<script>
		var obj = {
			xhr:new XMLHttpRequest(),
			chk_user:function()
			{
				var username = document.getElementById("usn").value;
				this.xhr.open("GET","http://localhost/samp/admin/chk_user.php?usn="+username,true)
				this.xhr.onreadystatechange = this.showUser;
			    this.xhr.send();
			},
			showUser:function()
			{
				if(this.readyState==4 && this.status==200)
				{
					alert(this.responseText);
				}
			}
			chk_email:function()
			{
				var username = document.getElementById("email").value;
				this.xhr.open("GET","http://localhost/samp/admin/chk_email.php?email="+email,true)
				this.xhr.onreadystatechange = this.showEmail;
			    this.xhr.send();
			},
			showEmail:function()
			{
				if(this.readyState==4 && this.status==200)
				{
					alert(this.responseText);
				}
			}
		}
			
	</script>
	<form method="post" action="create_user.php">

		<?php echo display_error(); ?>

		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" id = "usn" onblur="obj.chk_user()" value="<?php echo $username; ?>">
		</div>
		<div class="input-group">
			<label>Email</label>
			<input type="email" name="email" id = "email" onblur="obj.chk_email()" value="<?php echo $email; ?>">
		</div>
		<div class="input-group">
			<label>User type</label>
			<select name="user_type" id="user_type" >
				<option value=""></option>
				<option value="admin">Admin</option>
				<option value="user">User</option>
			</select>
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password_1">
		</div>
		<div class="input-group">
			<label>Confirm password</label>
			<input type="password" name="password_2">
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="register_btn"> + Create user</button>
		</div>
	</form>
	
</body>
</html>