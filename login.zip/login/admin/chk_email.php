<?php
extract($_GET);
$mysqli = new mysqli("localhost","root","","multi_login");

// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}

// Perform query   "SELECT *from users WHERE username='" . $usn . "'"
if ($result = $mysqli -> query( "SELECT *from users WHERE email='" . $email . "'")) {
  $res = $result -> num_rows;
  // Free result set
  $result -> free_result();
}
if($res==1)
{
	$res = "email already exists";
}
else
{
	$res = "email available";
}
$mysqli -> close();
echo ($res);
?>