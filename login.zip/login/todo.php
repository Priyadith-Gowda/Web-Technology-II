﻿<?php
	$errors = "";

	// connect to database
	$db = mysqli_connect("localhost", "root", "", "multi_login");
// not working properly
	// insert a quote if submit button is clicked
	if (isset($_POST['submit'])) {

		if (empty($_POST['task'])) {
			$errors = "You must fill in the task";
		}else{
			
			$task = $_POST['task'];
			$priority = $_POST['priority'];
			$query = "INSERT INTO tasks (task) VALUES ('$task')";
			$sql = "INSERT INTO tasks (task,prio,username) VALUES ('$task','$priority','vinny')";
			mysqli_query($db,$sql);
			
			
			header('location: todo.php');
		}
	}	

	// delete task
	if (isset($_GET['del_task'])) {
		$id = $_GET['del_task'];

		mysqli_query($db, "DELETE FROM tasks WHERE id=".$id);
		header('location: todo.php');
	}

	// select all tasks if page is visited or refreshed
	$tasks = mysqli_query($db, "SELECT * FROM tasks where username =" . $_SESSION['username']);

?>
<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="s1.css">
</head>

<body>
	<form method="post" action="index.php" class="input_form">
		<?php if (isset($errors)) { ?>
			<p><?php echo $errors; ?></p>
		<?php } ?>
		<input type="text" name="task" class="task_input">
		<select name="priority" class="priority_input">
    <option value="Low">Low</option>
    <option value="Medium">Medium</option>
    <option value="High">High</option>
        </select>
		<button type="submit" name="submit" id="add_btn" class="add_btn">Add Task</button>
	</form>


	<table>
		<thead>
			<tr>
				<th>N</th>
				<th style="width: 560px;">Tasks</th>
				<th>Priority</th>
				<th>Delete</th>
				
			</tr>
		</thead>

		<tbody>
			<?php $i = 1; while ($row = mysqli_fetch_array($tasks)) { ?>
				<tr>
					<td> <?php echo $i; ?> </td>
					<td class="task"> <?php echo $row['task']; ?> </td>
					<td class="priority"> <?php echo $row['priority']; ?> </td>
					<td class="delete"> 
						<a href="index.php?del_task=<?php echo $row['id'] ?>">x</a> 
					</td>
				</tr>
			<?php $i++; } ?>	
		</tbody>
	</table>

</body>
</html>