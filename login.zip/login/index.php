<!DOCTYPE html>
<?php 
	include('functions.php');

	if (!isLoggedIn()) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}
?>
<html>
    <head>
        <title>Home</title>
    <!--       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css"> !-->
		<link rel="stylesheet" href="h.css"/>
    </head>
    <body>
   
       <div class="website">
    
           <header>
              <div class="bgImg">
                  <div class="company">Nature</div>
                  <nav>
                      <ul>
                          <li><a href="#">Home</a></li>
                          <li><a href="#">About</a></li>
                          <li><a href="todo.php">Todo-List</a></li>
                          <li><a href="change_password.php">Change password</a></li>
                          <li><a href="index.php?logout='1'" style="color: red;">Logut</a></li>
                      </ul>
                  </nav>
                  <div class="quote">Quality lawn care reliable services</div>
                  <div class="subquote">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</div>
                    
              </div>
           </header>
           
           <div class="content">
           
           <div class="c1">We Propose<br>the best services</div>
           <div class="c2">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididun</div>
           </div>
             
           <div class="card-1">
               <div class="card-number">01</div>
               <div class="card-heading">Design & Planting</div>
               <div class="card-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</div>
                <a class="btn" href="#">Read More</a>
            </div>
           <div class="card-2">
               <div class="card-number">02</div>
               <div class="card-heading">Explore Things</div>
               <div class="card-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</div>
                <a class="btnn" href="#">Read More</a>
            </div>
            
            <div class="card-3">
               <div class="card-number">03</div>
               <div class="card-heading">Generate New Ideas</div>
               <div class="card-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</div>
               <a class="bttn" href="#">Read More</a>
            </div>
            <footer>
                <div class="aboutme">Know more about me</div>
                <div class="footercon">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididuntSed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium  magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam</div>
            </footer>
             <img class="leafa" src="images/5.jpg">
              <img class="leafb" src="images/5.jpg">
               <img class="leafc" src="images/5.jpg">
                <img class="leafd" src="images/5.jpg">
              
       </div>
    </body>
</html>