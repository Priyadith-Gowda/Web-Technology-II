How to run project:
1) Create a database called multi_login
2) create a table users with the following fields:
	-username - varchar(255)
	-email - varchar(50)
	-user_type - varchar(30)
	-password - varchar(255)
3) Start apache and mysql and launch site on browser
4) In order to create an admin, use a client like phpmyadmin and manually create a user with user_type admin. Use this user to login and be able to create other users.
5) open phpadmin change the user type user to admin use that admin details to create other users
TO-DO :
1.attendence of the users 
2.salary management 
3.some other links and ui in admin page
4.some task or work has to assigned to the users 
 