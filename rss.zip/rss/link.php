<?php
    header('Content-type:text/xml');
    $content = file_get_contents("http://localhost/rss/terms.xml");
    echo $content;
?>