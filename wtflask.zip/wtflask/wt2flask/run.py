from flask import Flask, render_template, request
from flask_mysqldb import MySQL
from datetime import date


app = Flask(__name__)


app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'apsystem'

mysql = MySQL(app)


@app.route('/recomendation/attendence', methods=['GET', 'POST'])
def index():
    if request.method == "GET":
        l=[]
        cur = mysql.connection.cursor()
        cur.execute("select employee_id,count(*) as c from attendance group By employee_id order by c DESC limit 5")
        
        itemdata = cur.fetchall()
        print(itemdata)
        mysql.connection.commit()
        cur.close()
        #print(itemdata)
        l1=[]
        
        for i in range(5):
               l.append(str(itemdata[i][0]).replace(" ", ""))
              #print(itemdata[i][0].strip(" "))
              # print(str(itemdata[i][0]))
        
        #l=['3','4','5','6','7']

        item=''.join(filter(str.isdigit, str(itemdata[0][0])))
        #print(l)
        #print('4' ==str(itemdata[0][0]))
        i='10'
        #print(i)
        #l=[4,1,7,8]
        #l.append(itemdata[0][0])
        #l.append(9)
        output=[]
        c = 0
        l2=[]
        for i in l:
         
         
         cur = mysql.connection.cursor()
         cur.execute("SELECT firstname,lastname,employee_id from employees where employee_id = %s",(str(i),))
         #i.replace(" ","")
         #l2.append(i)
         #print("-->",l2)
         
         name = cur.fetchall()
         output.append(name)
         mysql.connection.commit()
         cur.close()
         
         
         string = output[c][0][0] + " " + output[c][0][1]
         l1.append((string,output[c][0][2])) 
         c=c+1
       
        #return 'success'
        return render_template('index.html',itemdata=l1)


@app.route('/recomendation/hours', methods=['GET', 'POST'])
def rec_hours():
    if request.method == "GET":
        l=[]
        cur = mysql.connection.cursor()
        cur.execute("select employee_id,sum(num_hr) as s from attendance group By employee_id order by s DESC limit 5")
        
        itemdata = cur.fetchall()
        
        mysql.connection.commit()
        cur.close()
        #print(itemdata)
        l1=[]
        
        for i in range(5):
               l.append(str(itemdata[i][0]).replace(" ", ""))
              #print(itemdata[i][0].strip(" "))
              # print(str(itemdata[i][0]))
        
        #l=['3','4','5','6','7']
        item=''.join(filter(str.isdigit, str(itemdata[0][0])))
        #print(l)
        #print('4' ==str(itemdata[0][0]))
        i='10'
        #print(i)
        #l=[4,1,7,8]
        #l.append(itemdata[0][0])
        #l.append(9)
        output=[]
        c = 0
        l2=[]
        for i in l:
         
         
         cur = mysql.connection.cursor()
         cur.execute("SELECT firstname,lastname,employee_id from employees where employee_id = %s",(str(i),))
         #i.replace(" ","")
         #l2.append(i)
         #print("-->",l2)
         
         name = cur.fetchall()
         output.append(name)
         mysql.connection.commit()
         cur.close()
         string = output[c][0][0] + " " + output[c][0][1]
         l1.append((string,output[c][0][2])) 
         c=c+1
       
        #return 'success'
        return render_template('index.html',itemdata=l1)

@app.route('/recomendation/experience',methods=["GET"])
def experience():
    if request.method == "GET":
      cur = mysql.connection.cursor()
      cur.execute("SELECT employee_id,firstname,lastname FROM employees ORDER BY created_on ASC limit 5")
      data = cur.fetchall()
      mysql.connection.commit()
      cur.close()
      l=[]
      c=0
      for i in data:
      	name = i[1]+ " " + i[2]
      	l.append((name,i[0])) 

      return render_template('index.html',itemdata=l)



@app.route('/recomendation/demote/attendence', methods=['GET', 'POST'])
def attendens_demote():
    if request.method == "GET":
        l=[]
        cur = mysql.connection.cursor()
        cur.execute("select employee_id,count(*) as c from attendance group By employee_id order by c ASC limit 8")
        
        itemdata = cur.fetchall()
        
        mysql.connection.commit()
        cur.close()
        #print(itemdata)
        l1=[]
        print(itemdata)
        for i in range(6):
            k=str(itemdata[i][0]).replace(" ", "")
            if(len(k)>10):
                l.append(str(k))

              #print(itemdata[i][0].strip(" "))
              # print(str(itemdata[i][0]))
        
        #l=['3','4','5','6','7']
        item=''.join(filter(str.isdigit, str(itemdata[0][0])))
        print(l)
        #print('4' ==str(itemdata[0][0]))
        i='10'
        #print(i)
        #l=[4,1,7,8]
        #l.append(itemdata[0][0])
        #l.append(9)
        output=[]
        c = 0
        l2=[]
        for i in l:
         
         
         cur = mysql.connection.cursor()
         cur.execute("SELECT firstname,lastname,employee_id from employees where employee_id = %s",(str(i),))
         #i.replace(" ","")
         #l2.append(i)
         #print("-->",l2)
         
         name = cur.fetchall()
         output.append(name)
         mysql.connection.commit()
         cur.close()
         print(output)
         string = output[c][0][0] + " " + output[c][0][1]
         l1.append((string,output[c][0][2])) 
         c=c+1
       
        #return 'success'
        return render_template('index.html',itemdata=l1)


@app.route('/recomendation/demote/hours', methods=['GET', 'POST'])
def rec_hours_demote():
    if request.method == "GET":
        l=[]
        cur = mysql.connection.cursor()
        cur.execute("select employee_id,sum(num_hr) as s from attendance group By employee_id order by s ASC limit 8")
        
        itemdata = cur.fetchall()
        
        mysql.connection.commit()
        cur.close()
        #print(itemdata)
        l1=[]
        
        for i in range(6):
                k=str(itemdata[i][0]).replace(" ", "")
                if(len(k)>10):
                    l.append(str(k))
              #print(itemdata[i][0].strip(" "))
              # print(str(itemdata[i][0]))
        
        #l=['3','4','5','6','7']
        item=''.join(filter(str.isdigit, str(itemdata[0][0])))
        print(l)
        #print('4' ==str(itemdata[0][0]))
        i='10'
        #print(i)
        #l=[4,1,7,8]
        #l.append(itemdata[0][0])
        #l.append(9)
        output=[]
        c = 0
        l2=[]
        for i in l:
         
         
         cur = mysql.connection.cursor()
         cur.execute("SELECT firstname,lastname,employee_id from employees where employee_id = %s",(str(i),))
         #i.replace(" ","")
         #l2.append(i)
         #print("-->",l2)
         
         name = cur.fetchall()
         output.append(name)
         mysql.connection.commit()
         cur.close()
         string = output[c][0][0] + " " + output[c][0][1]
         l1.append((string,output[c][0][2])) 
         c=c+1
       
        #return 'success'
        return render_template('index.html',itemdata=l1)





@app.route('/home',methods=["GET"])
def home():
	if request.method == "GET":
		return render_template("home.html")




@app.route('/profile/<user>',methods=["GET","POST"])
def  profile(user):
  if request.method == "GET":
    #print(user)
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employees WHERE employee_id = %s",(str(user),))
    data = cur.fetchone()
    mysql.connection.commit()
    cur.close()
    name = data[2] + " " + data[3]
    return render_template('profile.html',data=data,name=name)

if __name__ == '__main__':
    app.run()