<?php

$myfile = fopen("tasks.txt", "r");
// Output one line until end-of-file
$a=array("Design the solution","Prepare for implementation","Prepare the test/QA environment","Install the product in the test/QA environment.");
$b=array("Implement distributed data feeds","Implement Source/390 data feeds on the test LPAR","Implement a business system in the test/QA environment.","Schedule jobs");
$c=array("Prepare the production environment","Install the product in the production environment.","Implement distributed data feeds in the production environment.","Implement a business system in the production environment.");
$random_keys=array_rand($a,3);
$str = $a[$random_keys[0]].";".$b[$random_keys[1]].";".$c[$random_keys[2]]." ";
echo $str;
//fwrite($myfile,$str);
fclose($myfile); 
?>