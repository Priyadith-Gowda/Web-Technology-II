<html>
<head>
<title>Peers</title>
<style>
	body{
		background-color:pink;
		background-position:cover;
		background-repeat:no-repeat;
		background-attachment:fixed;
		background-size:100% 100%;
	}
	table{
		width:100%;
		text-align:left;
	}
	table,th,td{
		border:1px solid #ccc;
		border-collapse:collapse;
		text-align:center;
		padding:5px;
	}
	table tr:nth-child(even){
	background-color: #eee;
	}
	table tr:nth-child(odd){
	background-color: #fff;
	}
	h1{
		color:grey;
	}
	<meta name="viewport" content="width=device-width, initial-scale=1">
</style>
<script>
            xhr = new XMLHttpRequest();
            scrollAmt = 20;
            count = 0;
            function getChunk()
            {
                scroll = document.body.scrollTop||document.documentElement.scrollTop;
                console.log(scroll);
                if(scroll>scrollAmt)
                {
                    scrollAmt = scroll;
                    xhr.onreadystatechange = showchunk;
                    xhr.open("GET","http://localhost/p2/wt2/admin/getchunk.php?count="+count++,true);
                    xhr.send();
                }
            }
            function showchunk()
            {
                console.log(xhr.status);
                if(xhr.readyState==4 && xhr.status==200)
                {
                    document.getElementById("content").innerHTML+=xhr.responseText;
                }
            }
            window.onscroll = getChunk;
</script>
</head>
<body onload="fetch()">
<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db = "apsystem";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);
?>
<h1>Peers of our Company</h2>
<table>
				<tr>
					<th>Name</th>
					<th>Position</th>
					<th>Member Since</th>
				</tr> <br>
<?php		
			$sql = "SELECT *, employees.id AS empid FROM employees LEFT JOIN position ON position.id=employees.position_id LEFT JOIN schedules ON schedules.id=employees.schedule_id";
			 $query = $conn->query($sql);
				while($row = $query->fetch_assoc()){
                      ?>
						<tr>
                          <td><?php echo $row['firstname'].' '.$row['lastname']; ?></td>
                          <td><?php echo $row['description']; ?></td>
                          <td><?php echo date('M d, Y', strtotime($row['created_on'])) ?></td>
                        </tr>
						<?php
					
				}
		
		?>
</table><br>	
<button type="button" onclick="myFunction()">Print</button>
<script>
function myFunction() {
  window.print();
}
</script>	
</body>
</html>