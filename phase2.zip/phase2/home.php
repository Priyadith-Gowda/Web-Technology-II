<!DOCTYPE html>
<html>
    <head>
        <title>Home</title>
		<link rel="stylesheet" href="h.css"/>
    </head>
	<script type="text/javascript">
		xhr = new XMLHttpRequest();
		var n = 2;
		function fetch(){
			xhr.onreadystatechange = showTasks;
			xhr.timeout=6000;
			xhr.ontimeout=backOff;
			xhr.open("GET","http://localhost/WT2/apsystem/updaterefresh.php",true);
			xhr.send();
			}
		function showTasks()
		{
		if(xhr.readystate == 4 || xhr.status == 200){
		var res = xhr.responseText;
		var resArr = res.split(";");
		//console.log(resArr);
		document.getElementById("t1").innerHTML = resArr[0];
		document.getElementById("t2").innerHTML = resArr[1];
		document.getElementById("t3").innerHTML = resArr[2];
		setTimeout(fetch,2000);
		n=2;
		}
		}

	function backOff()
	{
		n=n*2;
		console.log(n);
		setTimeout(fetch,n*1000);
	}

</script>
    <body onload = "fetch()">
   
       <div class="website">
    
           <header>
              <div class="bgImg">
                  <div class="company">Notarue</div>
                  <nav>
                      <ul>
                          <li><a href="admin/home.php">Admin Login</a></li>
                          <li><a href="aboutme.php">About Us</a></li>
                          <li><a href="peers.php">Colleagues</a></li>
                          <li><a href="../../rss/frontpage.html">T&C</a></li>
                          <li><a href="index.php?Logout='true'" style="color: red;">Logout</a></li>
                      </ul>
                  </nav>
                  <div class="quote">Quality and reliable service</div>
                  <div class="subquote">If you’re offered a seat on a rocket ship, don’t ask what seat! Just get on.</div>
                    
              </div>
           </header>
           
           <div class="content">
           
           <div class="c1">We Provide the best services to the customers</div>
           <div class="c2">If you’re offered a seat on a rocket ship, don’t ask what seat! Just get on.The characteristic of a good employee is to be a team player. Many jobs or projects require employees to be part of a team or special group. Team work is vital to the success of every business. Employees that strive to help others meet goals and deadlines are team players.</div>
		   </div>
             
           <div class="card-1">
               <div class="card-number">01</div>
               <div class="card-heading" style="font-size:14px;">Task</div>
               <div class="card-content" id="t1" style="font-size:14px;line-height: 1.5;">
			   </div>
               <!-- <a class="btn" href="#">Read More</a> !-->
            </div>
           <div class="card-2">
               <div class="card-number">02</div>
               <div class="card-heading" style="font-size:14px;">Task</div>
               <div class="card-content" id = "t2" style="font-size:14px;line-height: 1.5;"></div>
              <!--  <a class="btnn" href="#">Read More</a> !-->
            </div>
            
            <div class="card-3">
               <div class="card-number">03</div>
               <div class="card-heading" style="font-size:14px;">Task</div>
               <div class="card-content" id = "t3" style="font-size:14px;line-height: 1.5;"></div>
               <!--<a class="bttn" href="#">Read More</a>!-->
            </div>
            <footer>
                <div class="aboutme">Know more about me</div>
                <div class="footercon"><b>Leadership is the ability to facilitate movement in the needed direction and have people feel good about it.<br>The leader is the person who brings a little magic to the moment.</b></div>
            </footer>
             <img class="leafa" src="images/5.jpg">
              <img class="leafb" src="images/5.jpg">
               <img class="leafc" src="images/5.jpg">
                <img class="leafd" src="images/5.jpg">
              
       </div>
    </body>
</html>