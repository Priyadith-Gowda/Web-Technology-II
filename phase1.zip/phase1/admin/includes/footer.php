<footer class="main-footer">
    <div class="pull-right hidden-xs">
</footer>